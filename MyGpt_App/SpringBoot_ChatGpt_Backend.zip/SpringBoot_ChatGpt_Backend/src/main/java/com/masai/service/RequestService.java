package com.masai.service;

public interface RequestService {

	String getMyGptResponse(String userInput);
	
}
