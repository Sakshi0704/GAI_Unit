data = [("John", 25), ("Jane", 30)]

for name, age in data:
    print(f"{name} is {age} years old.")